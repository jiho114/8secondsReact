import React from 'react';
import Header from "../components/Header.jsx";
import NavBar from "../components/NavBar.jsx";
import Footer from "../components/Footer.jsx";
import { Link } from 'react-router-dom';
import { terms } from '../data/NoticeData.js'
import '../css/Signup.css'

const SignUp = () => {
  return (
    <div>
      <Header/>
      <NavBar/>
      <div className="signup">
        <h2>회원가입</h2>
        <hr />
        <form action="">
          <div className="idBox">
            <span>아이디</span>
            <input type="text" name="id" placeholder='6자 이상의 영문 혹은 영문과 숫자 조합' />
          </div>
          <div className="pwBox">
            <span>비밀번호</span>
            <input type="text" name="pw" placeholder='비밀번호를 입력해 주세요' />
          </div>
          <div className="pw2Box">
            <span>비밀번호 확인</span>
            <input type="text" name="pw2" placeholder='비밀번호를 한번 더 입력해 주세요' />
          </div>
          <div className="nameBox">
            <span>이름</span>
            <input type="text" name="name" placeholder='이름을 입력해 주세요' />
          </div>
          <div className="email">
            <span>이메일</span>
            <input type="text" name="email" placeholder='예) 8seconds@eight.kr' />
          </div>
          <div className="phone">
            <span>휴대폰</span>
            <input type="text" name="phone" placeholder='숫자만 입력해 주세요' />
          </div>
          <div className="termsOfUse">
            <div className="terms">
              <div className="termsCheck">
              <p>{terms[0].title}</p>
              <div className="checkInputBox">
              <input type="checkbox" />
              <label htmlFor="">이용약관에 동의합니다.</label>
              </div>
              </div>
              <div className="termsDesc">
                <p>{terms[0].description}</p>
              </div>
            </div>
            <div className="terms">
            <div className="termsCheck">
              <p>{terms[1].title}</p>
              <div className="checkInputBox">
              <input type="checkbox" />
              <label htmlFor="">이용약관에 동의합니다.</label>
              </div>
              </div>
              <div className="termsDesc">
                <p>{terms[1].description}</p>
              </div>
            </div>
          </div>
          <div className="SignupSubmitBtnBox">
            <button><Link to="/">취소</Link></button>
            <button><Link to="/">회원가입</Link></button>
          </div>
        </form>
      </div>
      <Footer/>
    </div>
  );
};

export default SignUp;