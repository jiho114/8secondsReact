import React from "react";
import Header from "../components/Header.jsx";
import NavBar from "../components/NavBar.jsx";
import Footer from "../components/Footer.jsx";
import { Link } from "react-router-dom";
import { RiKakaoTalkFill } from "react-icons/ri";
import '../css/Login.css'

const Login = () => {
  return (
    <div>
      <Header />
      <NavBar />
      <div className="login">
        <div className="loginContainer">
          <form className="loginInputBox">
            <h2>로그인</h2>
            <input type="text" name="id" placeholder="아이디를 입력해 주세요."/>
            <input type="text" name="pw" placeholder="비밀번호를 입력해 주세요." />
            <div className="loginCheckBox">
              <input type="checkbox" checked />
              <label htmlFor="">로그인 저장</label>
            </div>
            <button type="submit">로그인하기</button>
            <div className="IntegratedLoginBox">
              <button className="kakao">카카오 로그인</button>
              <button className="naver">네이버 로그인</button>
            </div>
          </form>
          <div className="loginSignUpBtn">
            <div className="loginSignUpTxtBox">
            <span>8 Seconds</span>
            <span>8 세컨즈</span>
            <span>8 秒</span>
            </div>
            <div className="loginSignupLink">
          <Link to="/signup">아직 회원이 아니시라면 클릭하세요!</Link> <br />
          <Link to="/signup">클릭 시 회원가입 페이지로 이동합니다.</Link>
          </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Login;
