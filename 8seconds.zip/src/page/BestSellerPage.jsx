import React from 'react';

const BestSellerPage = () => {
  return (
    <div>
      
    </div>
  );
};

export default BestSellerPage;