import React from 'react';

const NewProductPage = () => {
  return (
    <div>
      
    </div>
  );
};

export default NewProductPage;